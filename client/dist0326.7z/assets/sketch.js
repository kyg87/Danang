function setup() {

}

function draw() {
    ellipse(50, 50, 80, 80);
}